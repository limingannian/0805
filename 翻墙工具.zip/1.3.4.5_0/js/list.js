var proxyList = JSON.parse(localStorage.filters);
var bkg = chrome.extension.getBackgroundPage();
function fillList() {
    $("#tbody").html("");
    var listHtml = "";
    var tr = [];
    for(var d in proxyList) {
        tr.push(d);
        if(tr.length == 5) {
           listHtml += getRowHtml(tr);    
           tr = []; 
        }
    }
    if(tr.length > 0) {
        listHtml += getRowHtml(tr);
    }
    $("#tbody").append(listHtml);
    addDelete();
}

function getRowHtml(tr) {
    var htmlTr = "<tr>";
    for (var i = tr.length - 1; i >= 0; i--) {
        htmlTr += "<td>" + tr[i] + "<a href=\"#\"><img id=\""+tr[i]+"\" title=\"Delete\" src=\"img/del.png\"></a></td>";
    };
    htmlTr += "</tr>";
    return htmlTr;
}

$(function() {
   fillList();
   $('#clean').click(function() {
        localStorage.filters = "{}";
        bkg.RE_PAC();
        window.location.reload();
   });
   $('#reset').click(function() {
        localStorage.filters = bkg.defaultFilters;
        bkg.RE_PAC();
        window.location.reload();
   });  
   loadLang();
});
function addDelete(){
    for(var domain in proxyList){
        var target = document.getElementById(domain);
        target.onclick = function(target) {
            var d = target.currentTarget.id;
            delete proxyList[d];
            localStorage.filters = JSON.stringify(proxyList);
            fillList();
            bkg.RE_PAC();
        };
   }
}
function loadLang() {
    $('#tips').html(getMessage('filterTip1',"The following domain names will be proxied in the \"My Filters List\", free users limit to 1000, Premium user unlimited."));
    $('#clean').html(getMessage('clearAll',"Clear All "));
    $('#reset').html(getMessage('recover',"Recover Default "));
    $('#upgrade').html(getMessage('upgrade',"Upgrade to Premium"));
}



