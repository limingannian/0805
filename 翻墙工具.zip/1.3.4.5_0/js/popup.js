﻿/*(function($){
    $.fn.snow = function(options){
    var $flake = $('<div id="snowbox" />').css({'position': 'absolute','z-index':'9999', 'top': '-50px'}).html('&#10052;'),
    documentHeight  = $(document).height(),
    documentWidth   = $(document).width(),
    defaults = {
        minSize     : 5,
        maxSize     : 50,
        newOn       : 1000,
        flakeColor  : "#FFFFFF" 
    },
    options = $.extend({}, defaults, options);
    var interval= setInterval( function(){
    var startPositionLeft = Math.random() * documentWidth - 100,
    startOpacity = 0.5 + Math.random(),
    sizeFlake = options.minSize + Math.random() * options.maxSize,
    endPositionTop = documentHeight - 200,
    endPositionLeft = startPositionLeft - 500 + Math.random() * 500,
    durationFall = documentHeight * 10 + Math.random() * 5000;
    $flake.clone().appendTo('body').css({
        left: startPositionLeft,
        opacity: startOpacity,
        'font-size': sizeFlake,
        color: options.flakeColor
    }).animate({
        top: endPositionTop,
        left: endPositionLeft,
        opacity: 0.2
    },durationFall,'linear',function(){
        $(this).remove()
    });
    }, options.newOn);
    };
})(jQuery);
$(function(){
    $.fn.snow({ 
        minSize: 5, 
        maxSize: 30,
        newOn: 200  
    });
});*/
function initPremium() {
    var accountInfo = getMessage("account","Account Id");
	if (localStorage.pre) {
        $("#androidimg").removeClass("grayx");
        $('#androidimg').attr("href","https://cowapp.github.io/static/cow-proxy.apk");
		var e = parseFloat(localStorage.pre);
		bkg && e > bkg.premiumDays && (e = bkg.premiumDays);
        var pleftInfo = "Premium left: ";
        var dayInfo = " days";
        var payInfo = "Renewals";
        pleftInfo = getMessage("premium",pleftInfo);
        dayInfo = getMessage("day",dayInfo);
        payInfo = getMessage("pay",payInfo);
		var n = pleftInfo + e + dayInfo +"<a href='packages.html' target='_blank' style='text-decoration: underline;'><b>" + payInfo+ "</b></a>";
		$("#premium_left").html(n)
	} else createFreeNotify("ad" + (new Date).getTime())
    $("#uuid").html("<span class='ccc'>" + accountInfo + ": </span> " + localStorage.uid);
}
function getCurrentNode(){
    var htmlNode = $('#currentNode')[0].innerHTML;
        var currentNode = {};
        for (var i = 0; i< ipData.length; i++) {
            currentNode = ipData[i];
            if(htmlNode.indexOf(currentNode.host) > -1){
                console.log("currentNode-:" + currentNode.name);
                break;
            }
        }
        var itemNode = {
                proxyIsWork: true,  
                scheme:currentNode.scheme,
                proxyServer: currentNode.host,
                proxyPort: currentNode.port,
                passlist: bypass,
                html:htmlNode
        };
    return itemNode;
}
function isClosed(itemNode){
    var s1 = $('#s1');
    var s2 = $('#s2');
    if(localStorage.all == "true") {
        $('#btn-on-off').prop("checked", true);
        s1.addClass('slider-green');
    }else if(localStorage.smart == "true") {
        $('#btn-smart').prop("checked", true);
        s2.addClass('slider-green');
    }
    if(localStorage.all == "false" && localStorage.smart == "false"){
        chrome.browserAction.setIcon({path: 'img/icon64-gray.png'});
        // сохранить параметры
        chrome.proxy.settings.clear({scope:"regular"}, function(){});
        return true;
    }
    return false;
}

$(function() {
    loadLang();
    var s1 = $('#s1');
    var s2 = $('#s2');
    isClosed();
    // на прокси-сервере
    $('#btn-on-off').click(function() {
        var itemNode = getCurrentNode();
        if(!s1.hasClass('slider-green')) {
        } else {
            s1.removeClass('slider-green');
            localStorage.all = false;
            isClosed(itemNode);
            return;
        }
        if(currentNode.name == "Loading") {
            $("body").html("<h3 style=\"color:black;padding:25 5 5 5;\">Oops, CowProxy try to load proxies list  but failed. Please check your network and restart. <br><br>К сожалению, CowProxy пытается загрузить список прокси, но не удалось. Проверьте свою сеть и перезапустите.</h3>")
            return;
        }else{
            // close smart
            if(s2.hasClass('slider-green')) {
                $('#btn-smart').prop("checked", false);
                s2.removeClass('slider-green');
                localStorage.smart = false;
            }
            s1.addClass('slider-green');
            localStorage.all = true;
            changeOptions(itemNode,null,s1);
        }
    });
    $('#btn-smart').click(function() {
        //clickPopCurrent();
        var itemNode = getCurrentNode();
        if(!s2.hasClass('slider-green')) {
        } else {
            s2.removeClass('slider-green');
            localStorage.smart = false;
            isClosed(itemNode);
            return;
        }
        if(currentNode.name == "Loading") {
            $("body").html("<h3 style=\"color:black;padding:25 5 5 5;\">Oops, CowProxy try to load proxies list  but failed. Please check your network and restart. <br><br>К сожалению, CowProxy пытается загрузить список прокси, но не удалось. Проверьте свою сеть и перезапустите.</h3>")
            return;
        }else{
            s2.addClass('slider-green');
            // close all
            if(s1.hasClass('slider-green')) {
                $('#btn-on-off').prop("checked", false);
                s1.removeClass('slider-green');
                localStorage.all = false;
            }
            localStorage.smart = true;
            changeOptions(itemNode,null,s2);
        }
    });

    // добавить серверы
    $(document).ready(function(){
        clickPopCurrent();
        loadSettings(bkg);
        initPremium();
        ipData = bkg.ipdata;
        bypass = bkg.allpasslist;
        console.log(JSON.stringify(bypass));
        if(!ipData){
             $("#nodes").append('<li><a><img class="flags" src="img/us.png">&nbsp&nbsp&nbsp&nbspLoading...</a></li>');
             return;
        }
        if(!ipData || ipData.length == 0) {
            return;
        }
        for (var i = 0; i< ipData.length; i++) {
            var per = ipData[i];
            var disabled = false;
            if(per.pending){
                disabled = true;
            }
            var temp = disabled ? '<li class="disabled"><a><img id="node_@" class="flags" src="img/#.png">&nbsp&nbsp&nbsp&nbsp$</a></li>' : '<li><a><img id="node_@" class="flags" src="img/#.png">&nbsp&nbsp&nbsp&nbsp$</a></li>';
            var titleStr = per.pr ? per.name + "<span>@<b style='color:green;'>Premium</b></span>" : per.name + "<span>@<span style='color:orange;font-style:oblique;'>Free</span></span>"; //per.ping ? per.name + "&nbsp" + parseInt(per.ping) + "ms" : per.name;
            temp = temp.replace("#",per.icon).replace("$",titleStr).replace("@",per.host);
            $("#nodes").append(temp);
        };
        // выпадающее меню init
        var dd = new DropDown( $('#dd') );
        $(document).click(function() {
            $('.wrapper-dropdown-3').removeClass('active');
        });
        // узел init по умолчанию
        chrome.storage.local.get([ 'proxyIsWork', 'proxyServer', 'proxyPort', "scheme", "passlist", "html"], function(items)  {
            console.log("local select ->",JSON.stringify(items));
            if(items && items.html) {
                $('#currentNode').append(items.html);
            }else{	
                var temp = '<a><img id="node_@" class="flags" src="img/#.png">&nbsp&nbsp&nbsp&nbsp$</a>';
                temp = temp.replace("#",ipData[0].icon).replace("$",ipData[0].name).replace("@",ipData[0].host);
                $('#currentNode').append(temp);
                if(ipData[0].name == "Loading") {
                    s1.removeClass('slider-green');
                    s2.removeClass('slider-green');
                    return;
                }
                if(bkg.conn) {
                    bkg.conn.send("ping");
                    console.log("send ping...");
                }
            }
        });
    });
});
var ipData = undefined;
var bkg = chrome.extension.getBackgroundPage();;
var bypass = undefined;
function DropDown(el) {
    this.dd = el;
    this.placeholder = this.dd.children('span');
    this.opts = this.dd.find('ul.dropdown > li');
    this.val = '';
    this.index = -1;
    this.initEvents();
}
DropDown.prototype = {
    initEvents : function() {
        var obj = this;

        obj.dd.on('click', function(event){
            $(this).toggleClass('active');
            return false;
        });

        obj.opts.on('click',function(){
            if(this.innerHTML.indexOf("get-premium") > -1){
                return gotoPage("packages.html");
            }
            var opt = $(this);
            obj.val = opt.text();
            obj.index = opt.index();
            obj.placeholder[0].innerHTML = this.innerHTML;
            var proxy = ipData[obj.index];
            //***
            if(proxy.pr && !localStorage.pre) {
                return gotoPage("packages.html");
            }

            //***
            changeOptions({
                proxyIsWork: true,
                scheme:proxy.scheme,
                proxyServer: proxy.host,
                proxyPort: proxy.port,
                passlist: bypass,
                html:this.innerHTML
            }, true, );                      
        });
    },
    getValue : function() {
        return this.val;
    },
    getIndex : function() {
        return this.index;
    }
}
