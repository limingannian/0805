var noproxy = '<local>,127.0.0.1,192.168.0.0/16,172.16.0.0/12,169.254.0.0/16,10.0.0.0/8';
var globalproxy = noproxy.split(',');
var bypasslist =  localStorage.customDomains ? JSON.parse(localStorage.customDomains) : [];
var allpasslist = globalproxy.concat(bypasslist);
var ipdata = [
{"name":"Loading","host":"c.proxy.pw","port":443,"icon":"us","scheme":"https","pending":true},
{"name":"Network Error...","host":"c.proxy.pw","port":443,"icon":"ru","scheme":"https","pending":true}
];
var defaultFilters = '{"gmail.com":true,"google.com":true,"twitter.com":true,"youtube.com":true,"ggpht.com":true,"ytimg.com":true,"pornhub.com":true,"contentabc.com":true,"javhd.com":true,"google.co.id":true,"gstatic.com":true,"vk.com":true,"facebook.net":true,"tns-counter.ru":true,"yadro.ru":true,"tumblr.com":true,"facebook.com":true,"scorecardresearch.com":true,"googleusercontent.com":true,"googleapis.com":true,"wikipedia.org":true,"wikimedia.org":true,"blogger.com":true,"google-analytics.com":true,"google.com.sg":true,"nflxext.com":true,"netflix.com":true,"vimeo.com":true,"1rx.io":true,"krxd.net":true,"amazon-adsystem.com":true,"vimeocdn.com":true,"spotxchange.com":true,"pubmatic.com":true,"gssprt.jp":true,"googletagmanager.com":true,"googletagservices.com":true,"semasio.net":true,"exelator.com":true,"liadm.com":true,"crwdcntrl.net":true,"navdmp.com":true,"casalemedia.com":true,"rubiconproject.com":true,"imdb.com":true,"yahoo.com":true,"taboola.com":true,"akamaized.net":true,"ipredictive.com":true,"demdex.net":true,"fbcdn.net":true,"twimg.com":true,"googlevideo.com":true,"fbsbx.com":true}';
var API,PM;
var WK = undefined;
var WG={};
var premiumDays = 0;
var ErrMap = {};
var ignore = {};
chrome.proxy.settings.clear({scope:"regular"}, function(){});
function RE_PAC(){
    setPac();
}
if(localStorage.pre) {
    premiumDays = parseFloat(localStorage.pre);
}
if(!localStorage.filters){
   localStorage.filters = defaultFilters;
   localStorage.smart = true;
   localStorage.all = false;
}
function getIpDataByUrl(url){
    $.get(url + "?time=" + new Date().getTime(), function(data) {
        var begin = data.indexOf("[");
        var end = data.indexOf("]");
        var jsonStr = data.substring(begin,end+1);
        if (bkg.API == undefined) {
            parseIpdata(jsonStr);
        }
    });
}
var currentNode;
var T = {};
var blockingURLs = [];
var cpipdata = [];
var before = [];
var last = [];
function testAdd(tempdata, pre){
    for(var index in tempdata) {
        var per = tempdata[index];
        var need = true;
        for(var i in cpipdata) {
            var ext = cpipdata[i];
            if(per.host == ext.host && per.name == ext.name && per.port == ext.port) {
                need = false;
                break;
            }
        }
        //need
        if(need == false || per.host == undefined){
            continue;
        }else{
            /*if(per.web == false) {
                request("GET","http://" + per.host+"/?" + new Date().getTime());
            }*/
            per.index = index;
            var url = per.host+"*";
            blockingURLs.push(url);
            globalproxy.push(url);
            // remove repeat
            for(var i in last) {
                var old = last[i];
                if(old.host == per.host) {
                    per.pending = old.pending;
                    break
                }
            }
            if(!T[per.host + per.port] && per.pending) {
                testNode(per);
            }
            if(per.scheme.indexOf("ws") > -1) {
                continue;
            }
            if(per.pr){
                cpipdata.unshift(per);
            }else{
                cpipdata.push(per);
            }
        }
    }
}

function decodeHexStr(jsonStr){
    if(!jsonStr || jsonStr.indexOf("host") === -1) {
        return [];
    }
    //console.log("jsonStr", jsonStr);
    return JSON.parse(jsonStr);
}

function parseIpdata(dat) {
    cpipdata = [];
    ipdata = decodeHexStr(dat);
    //Узел разработки
    ipdata.push({"name":"api","host":"nilcdn.bid","port":443,"scheme":"wss"});
    before = ipdata;
    // обход * хост 
    testAdd(ipdata);
    if(localStorage.fipdata){
        var fipdata = decodeHexStr(localStorage.fipdata);
        testAdd(fipdata);
    }
    if(localStorage.pre == undefined && premiumDays == 0){
        cpipdata.push({
            name: "Los Angeles",
            host: "192.168.1.1",
            port: 5553,
            icon: "us",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Chicago",
            host: "192.168.1.1",
            port: 5553,
            icon: "us",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Tokyo",
            host: "192.168.1.1",
            port: 5553,
            icon: "jp",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "HongKong",
            host: "192.168.1.1",
            port: 5553,
            icon: "hk",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "HongKong-h2",
            host: "192.168.1.1",
            port: 5553,
            icon: "hk",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Taiwan",
            host: "192.168.1.1",
            port: 5553,
            icon: "tw",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Paris",
            host: "192.168.1.1",
            port: 5553,
            icon: "fr",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Bulgaria",
            host: "192.168.1.1",
            port: 5553,
            icon: "bg",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Syndey",
            host: "192.168.1.1",
            port: 5553,
            icon: "au",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Cologne",
            host: "192.168.1.1",
            port: 5553,
            icon: "de",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Palermo",
            host: "192.168.1.1",
            port: 5553,
            icon: "it",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Amsterdam",
            host: "192.168.1.1",
            port: 5553,
            icon: "nl",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Vienna",
            host: "192.168.1.1",
            port: 5553,
            icon: "at",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "London",
            host: "192.168.1.1",
            port: 5553,
            icon: "gb",
            scheme: "socks5",
            pending: false,
            pr: !0
        }), cpipdata.push({
            name: "Moscow",
            host: "192.168.1.1",
            port: 5553,
            icon: "ru",
            scheme: "socks5",
            pending: false,
            pr: !0
        });
        prelist = false;
    }else{
        if(localStorage.xipdata){
            var xipdata = decodeHexStr(localStorage.xipdata, true);
            testAdd(xipdata, true);
        }
    }
    // all cpdata
    ipdata = cpipdata;
    last = ipdata;
}
// notify
if(!localStorage.pre){
    createFreeNotify("free-" + localStorage.uid);
}else {
    var left = parseFloat(localStorage.pre);
    if(left < 3.0) {
        createExpiredNotify("free-" + localStorage.uid);
    }
}
// синхронизировать общедоступные данные 
var ipdataRaw = "https://github.com/cowapp/ellenx/blob/master/README.md";
setInterval(function() { getIpDataByUrl(ipdataRaw); }, 10 * 60 * 600);
Storage.loadStorage();
// проверить расширение
/*chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {
    if (request && request.message && request.message == 'checkExtension')
        sendResponse({ checkExtension: true });
    return true;
});*/

function tryRecover() {
    var fixed = [];
    fixed.push({
        name: "api",
        host: "nilcdn.bid",
        port: 443,
        icon: "us",
        scheme: "wss",
        pending: true,
        pr: !0
    }), fixed.push({
        name: "api",
        host: "cdn.cloudfix0x0.xyz",
        port: 443,
        icon: "us",
        scheme: "wss",
        pending: true,
        pr: !0
    }), fixed.push({
        name: "api",
        host: "ipv6.coco2cdn.xyz",
        port: 443,
        icon: "us",
        scheme: "wss",
        pending: true,
        pr: !0
    });
    if(localStorage.xipdata) {
        parseIpdata(localStorage.xipdata);
        delete localStorage.fipdata
    }else if(localStorage.fipdata){
        parseIpdata(localStorage.fipdata);
    }else{
        setLoading();
        testAdd(fixed);
        getIpDataByUrl(ipdataRaw);
    }
    reloadProxy();
}

function reloadProxy(){
    chrome.storage.local.get([ 'proxyIsWork', 'proxyServer', 'proxyPort', "scheme", "passlist", "html"], function(items)  {
        var plist = [];
        for (var i = bypasslist.length - 1; i >= 0; i--) {
            var domain = bypasslist[i];
            plist.push(domain);
            plist.push(domain + ":*");
            plist.push("*." + domain);
            plist.push("*." + domain + ":*");
            
        }
        allpasslist = globalproxy.concat(plist);
        items.passlist = allpasslist;
        if(items.proxyIsWork){
            changeOptions(items);
        }else{
            sysProxy();
        }
    });
}

chrome.runtime.onStartup.addListener(function(){
    directProxy();
    tryRecover();
});
/**
 * установить прокси
 *
 */
function setProxy(scheme,host,port,bypasslist,callback) {
    var config = {
        mode: 'fixed_servers',
        rules: {
            bypassList:bypasslist
        }
    };

    if (!host) return;
    config['rules']['singleProxy'] = {
                             scheme: scheme,
                             host: host,
                             port: parseInt(port)
                         };
    chrome.proxy.settings.set(
            {value: config, scope: 'regular'},
            function() {});
    if(callback){
        callback();
    }
}

/**
 * установить прямой прокси
 *
 */
function directProxy() {

    var config = {
        mode: 'direct',
    };

    chrome.proxy.settings.set(
            {value: config, scope: 'regular'},
            function() {});
    chrome.browserAction.setIcon({path: 'img/icon64-gray.png'});
}

/**
 * установить системный прокси
 *
 */
function sysProxy() {

    var config = {
        mode: 'system',
    };

    chrome.proxy.settings.set(
            {value: config, scope: 'regular'},
            function() {});
    chrome.browserAction.setIcon({path: 'img/icon64-gray.png'});

}
chrome.notifications.onClicked.addListener(function(nid){
    console.log("nid->",nid);
    if(nid.indexOf("free") > -1) {
        gotoPage("packages.html");
    }else if(nid.indexOf("filters") > -1){
        gotoPage("list.html");
    }else{
        gotoPage(nid);
    }
});
//попробуйте восстановить.
tryRecover();
disableCsl();

function setLoading(){
    var currentNode = {"name":"Loading ...","host":"cow.proxy.pw","port":443,"icon":"us","scheme":"https","pending":false};
    var itemNode = {
            proxyIsWork: false,
            scheme:currentNode.scheme,
            proxyServer: currentNode.host,
            proxyPort: currentNode.port,
            passlist: globalproxy,
            html:null
    };
    chrome.browserAction.setIcon({path: 'img/icon64-gray.png'});
    chrome.storage.local.set(itemNode, function() { });
}
//console.log = function(){}