var bkg = chrome.extension.getBackgroundPage();
var customDomains = localStorage.customDomains;

function checkDomain(value) {
	var Regx = /^[A-Za-z0-9]*$/;
	if (Regx.test(value.replace(/\./g, ""))) {
		return true;
	} else {
		return false;
	}
}
$("#edit_bt").click(function(e) {
	$("#direct_domains").removeAttr("disabled");
	$("#direct_domains").css("border", "2px orange solid");
	$("#direct_domains").css("background-color", "#fff");
});
$("#save_bt").click(function(e) {
	$("#direct_domains").attr("disabled", "disabled");
	$("#direct_domains").css("background-color", "#EEEEEE");
	$("#direct_domains").css("border", "1px green solid");
	var domains = $("#direct_domains").val().split("\n");
	bkg.bypasslist = [];
	if (domains.length > 0) {
		for (var i in domains) {
			var domain = domains[i];
			if (domain.indexOf(".") == -1) continue;
			if (checkDomain(domain)) {
				bkg.bypasslist.push(domain);
			}
		}
		localStorage.customDomains = JSON.stringify(bkg.bypasslist);
	} else {
		localStorage.customDomains = JSON.stringify([]);
	}
	bkg.reloadProxy();
	updateUi();
});

function updateUi() {
	if (localStorage.customDomains && localStorage.customDomains.indexOf(".") > -1) {
		var cdomains = JSON.parse(localStorage.customDomains);
		var tempStr = "";
		for (var i in cdomains) {
			tempStr = tempStr + cdomains[i].replace(/\*/g, "") + "\n";
		}
		$("#direct_domains").val(tempStr);
	} else {
		$("#direct_domains").val("127.0.0.1\nlocalhost\nadd domain name\nadd domain name\nadd domain name");
	}
}
updateUi();

function checkOut(pkg) {
	if (bkg.PM) {
		var query = "?uid=" + localStorage.uid + "&pkg=" + pkg;
		window.location = bkg.PM + query;
	} else {
		alert("Unable to connect to the server. \nTry restarting your browser.");
	}
}
$("#pre_m").click(function(e) {
	checkOut("m");
});
$("#pre_y").click(function(e) {
	checkOut("y");
});

$(function() {
	$('#pkgs').html(getMessage('packages',"Extra Premium packages"));
	$('#warming').html(getMessage('warming',"Warning: Do not uninstall the cow after purchase, otherwise you will lose the advanced plan account ID of the payment."));
});