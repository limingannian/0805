function Storage() { }

Storage.UUID = null;
Storage.callbackLoad = null;

Storage.loadStorage = function() {
    chrome.storage.sync.get(['uuid'], function(items) {
        if(items.uuid == undefined)
            items.uuid = UUID.create().toBytes();

        Storage.setUUIDitem(items.uuid);
        if(Storage.callbackLoad != null)
            Storage.callbackLoad();
    });
};

Storage.setUUIDitem = function(uuid) {
    chrome.storage.sync.set({ uuid: uuid }, function() {});
    Storage.UUID = uuid;
};
