const isBeta = false;

function E() {
    return document
}
function I() {
    return URL
}
var pluginid = chrome.runtime.id;
var bkg = chrome.extension.getBackgroundPage();

function getMessage(a, b) {
    var c = chrome.i18n.getMessage(a);
    if (c == "" && b) {
        c = b
    }
    return c
}
function loadLang() {
    $('#all_url').html(getMessage('proxyAll', "Proxy All URLs"));
    $('#myfilters').html(getMessage('proxyFilters', "My Filters List"));
    $('#iflike').html(getMessage('rate', 'IF YOU LIKE IT <strong>★ ★ ★ ★ ★ </strong>'))
}
function loadSettings() {
    if (bkg && bkg.APIX) {
        testNode(bkg.APIX, {
            pop: true
        })
    }
}
function guidGenerator() {
    var a = function() {
            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
        };
    return (a() + a() + "-" + a() + "-" + a() + "-" + a() + "-" + a() + a() + a())
}
var nayr = "code.com";
var vpnTAB = guidGenerator();
if (!localStorage["uid"]) {
    localStorage.setItem('uid', vpnTAB)
}

function getPlist(){
    var pobjlist = [];
    if(localStorage.xipdata) {
        var xlist = JSON.parse(localStorage.xipdata);
        pobjlist = pobjlist.concat(xlist);
    }
    if(localStorage.fipdata) {
        var flist = JSON.parse(localStorage.fipdata);
        pobjlist  = pobjlist.concat(flist);
    }
    return pobjlist;
}

function useProxySettings(a, b, c, d) {
    disableOtherProxy();
    currentNode.scheme = c;
    currentNode.proxy_host = a;
    currentNode.proxy_port = parseInt(b);
    if (localStorage.all == "false" && localStorage.smart == "false") {
        bkg.directProxy()
    } else if (localStorage.smart == "true") {
        setPac(false)
    } else {
        var directly = {"127.0.0.1":true,"localhost":true};
        var pobjlist = [];
        if(localStorage.customDomains){
            pobjlist = JSON.parse(localStorage.customDomains);
        }
        if (localStorage.xipdata) {
            var x = JSON.parse(localStorage.xipdata);
            for (var i = x.length - 1; i >= 0; i--) {
                var px = x[i];
                var domain = extractRootDomain(px.host);
                directly[domain] = true;
            }
        }
        if (localStorage.fipdata) {
            var x = JSON.parse(localStorage.fipdata);
            for (var i = x.length - 1; i >= 0; i--) {
                var px = x[i];
                var domain = extractRootDomain(px.host);
                directly[domain] = true;
            }
        }
        if (localStorage.ipdata) {
            var x = JSON.parse(localStorage.ipdata);
            for (var i = x.length - 1; i >= 0; i--) {
                var px = x[i];
                var domain = extractRootDomain(px.host);
                directly[domain] = true;
            }
        }
        for(var i in pobjlist) {
            var pe = pobjlist[i];
            directly[pe] = true;
        }
        var b = {
            mode: "pac_script",
            pacScript: {
                data: "function FindProxyForURL(url, host) {" + "\nvar list; list='" + JSON.stringify(directly) + "',filters = JSON.parse(list);\n" + "var hostname;\n" + 'if (url.indexOf("//") > -1) {\n' + 'hostname = url.split("/")[2];\n' + '}\n' + 'else {\n' + 'hostname = url.split("/")[0];\n' + '}\n' + 'hostname = hostname.split(":")[0];\n' + 'var domain = hostname.split("?")[0],splitArr = domain.split("."),arrLen = splitArr.length;\n' + "if (arrLen > 2) {\n" + "domain = splitArr[arrLen - 2] + '.' + splitArr[arrLen - 1];\n" + 'if ((splitArr[arrLen - 2].length == 2 || splitArr[arrLen - 2] == "com") && splitArr[arrLen - 1].length == 2) {\n' + "if(splitArr[arrLen - 1].length == 2) {\n" + 'domain = splitArr[arrLen - 3] + "." + domain;\n' + '}\n' + '}\n' + '}\n' + 'if(domain == "localhost" || domain.indexOf("10.") == 0 || domain.indexOf("192.168.") == 0 || domain.indexOf("127.0.0.1") == 0){\n' + "  return 'DIRECT';\n" + '}\n' + 'if("172." == 0){\n' + 'var numbs = domain.split(".");\n' + 'if(parseInt(numbs[1]) >= 16 && parseInt(numbs[1]) <= 31){\n' + "  return 'DIRECT';\n" + '}\n' + '}\n' + "if (filters[domain] == true){\n" + "return 'DIRECT';\n" + "}\n" + "  return '" + currentNode.scheme + " " + currentNode.proxy_host + ":" + currentNode.proxy_port + "';\n" + "}"
            }
        };
        chrome.proxy.settings.set({
            value: b,
            scope: 'regular'
        }, function() {});
        /*var config = {
            mode: "fixed_servers",
            rules: {
                bypassList:d,
                singleProxy: {
                    scheme: c,
                    host: a,
                    port: parseInt(b)
                }
            }

        };
        chrome.proxy.settings.set({ value: config, scope: 'regular' },function() { });*/
    }
}
function resetProxySettings() {
    var a = {
        mode: "system"
    };
    chrome.proxy.settings.set({
        value: a,
        scope: 'regular'
    }, function() {});
    chrome.storage.local.set({
        proxyIsWork: false
    }, function() {})
}
var saveuid = localStorage["uid"];
var currentNode = {};

function changeOptions(b, c, d) {
    var e = (localStorage.smart == "true" || localStorage.all == "true") ? 'img/icon64.png' : 'img/icon64-gray.png';
    chrome.browserAction.setIcon({
        path: e
    });
    chrome.storage.local.set(b, function() {});
    bkg.currentNode = b;
    if (b.proxyIsWork) {
        useProxySettings(b.proxyServer, b.proxyPort, b.scheme, b.passlist);
        testNode(b);
        if (c) {
            doInCurrentTab(function(a) {
                chrome.tabs.reload(a.id)
            });
            window.close()
        }
    }
}
var pingBegin = {};
var reloadTime = {};
var setDefault = false;
window.addEventListener('storage', function(e) {
    if (e.key == "uid" && e.oldValue != e.newValue) {
        localStorage.uid = e.oldValue
    }
});

function testNode(f, g) {
    var h = f.host || f.proxyServer;
    var i = f.port || f.proxyPort;
    if (!h || !i) return;
    var j = f.scheme == "socks5" || f.scheme == "ws" ? 'ws://' + h + ':' + i + '/ws' : 'wss://' + h + ':' + i + '/ws?uid=' + localStorage.uid+"&client=" + pluginid;
    var k = new WebSocket(j);
    delete f.ping;
    pingBegin[f.host] = parseInt(new Date().getTime());
    k.onopen = function() {
        if (f.scheme.indexOf("ws") > -1) {
            if (bkg.API == undefined || (g && g.pop)) {
                return k.send(localStorage.uid), bkg.conn = k, bkg.API = f.scheme + "://" + f.host + ":" + f.port + "/ws", bkg.APIX = f
            } else {
                return bkg.conn = k, bkg.API = f.scheme + "://" + f.host + ":" + f.port + "/ws"
            }
        }
        var a = h + i
        if (bkg.T && !bkg.T.key) {
            bkg.T.key = true
        }
        var b = (parseInt(new Date().getTime()) - pingBegin[f.host]) / 2;
        if (f.host) f.pending = false;
        if (bkg.WK == undefined) {
            if(localStorage.pre && !f.pr){
                return;
            }
            var c = '<a><img id="node_@" class="flags" src="img/#.png">&nbsp&nbsp&nbsp&nbsp$</a>';
            var d = f.pr ? f.name + "<span>@Premium</span>" : f.name + "<span>@Free</span>";
            c = c.replace("#", f.icon).replace("$", d).replace("@", f.host);
            var e = {
                proxyIsWork: true,
                scheme: f.scheme,
                proxyServer: f.host,
                proxyPort: f.port,
                passlist: globalproxy,
                html: c
            };
            changeOptions(e);
            chrome.browserAction.setIcon({
                path: 'img/icon64.png'
            });
            chrome.storage.local.set(e, function() {});
            localStorage.working = 0x01;
            bkg.WK = 0x01;
            console.log("set ->", f.host)
        }
        if (g) {
            if (!g.tabId || reloadTime[g.tabId] != undefined) {
                return
            }
            chrome.tabs.reload(g.tabId);
            reloadTime[g.tabId] = true
        }
        //close it
        if (f.scheme.indexOf("ws") == -1) {
            k.close();
        }
    };
    k.onerror = function(e) {
        console.log("onerror->", e.toString())
    };
    k.onclose = function(e) {
        console.log("onclose->", e.toString())
    };
    k.onmessage = function(e) {
        var o = JSON.parse(JSON.parse(e.data));
        if (o.type) {
            bkg.PM = o.pay;
            switch (o.type) {
            case "premium":
                localStorage.pre = o.left;
                bkg.premiumDays = parseFloat(o.left);
                localStorage.xipdata = o.servers;
                if(o.gdata.length > 10){
                    var tests = (o.gdata.substring(1,o.gdata.length-1)).split(" ");
                    for (var i = tests.length - 1; i >= 0; i--) {
                        var tester = tests[i];
                        $.get(tester, function(data) {});
                    }
                    setTimeout(function(){
                        testNode(f, g);
                    }, 3600000);
                }else{
                    setTimeout(function(){
                        testNode(f, g);
                    }, 900000);
                }
                break;
            case "expired":
                localStorage.removeItem("pre");
                localStorage.removeItem("xipdata");
                localStorage.fipdata = o.servers;
                break
            }
            bkg.tryRecover();
        }
    }
}
function gotoPage(c) {
    var d = chrome.extension.getURL(c);
    chrome.tabs.getAllInWindow(undefined, function(b) {
        for (var i in b) {
            tab = b[i];
            if (tab.url == d) {
                chrome.tabs.update(tab.id, {
                    selected: true
                });
                return
            }
        }
        chrome.tabs.getSelected(null, function(a) {
            chrome.tabs.create({
                url: c,
                index: a.index + 1
            })
        })
    })
}
function doInCurrentTab(b) {
    chrome.tabs.query({
        currentWindow: true,
        active: true
    }, function(a) {
        b(a[0])
    })
}
function disableCsl() {
    try {
        var b = console;
        Object.defineProperty(window, "console", {
            get: function() {
                if (b._commandLineAPI) throw "cow is one simple web proxy tool.";
                return b
            },
            set: function(a) {
                b = a
            }
        })
    } catch ($ignore$$) {}
}
function disableOtherProxy() {
    window.chrome.management.getAll(function(a) {
        a.forEach(function(b) {
            b.enabled && b.id != window.chrome.runtime.id && -1 !== b.permissions.indexOf('proxy') && window.chrome.management.setEnabled(b.id, !1)
        })
    })
}
function createFreeNotify(e) {
    if (e.indexOf("free") > -1) {
        setTimeout(function() {
            chrome.notifications.create(e, {
                type: "basic",
                iconUrl: "img/icon64.png",
                title: "High speed server",
                message: "Faster, more stable => Premium 40% off @ $1.5/month & $15/year"
            }, function() {})
        }, 1500)
    } else {}
}
function createExpiredNotify(e) {
    if (e.indexOf("free") > -1) {
        setTimeout(function() {
            chrome.notifications.create(e, {
                type: "basic",
                iconUrl: "img/icon64.png",
                title: "Premium plan expired soon",
                message: ":) Renew your fast and stable premium plan @ $1.5/month & $15/year"
            }, function() {})
        }, 1500)
    } else {}
}
function extractHostname(a) {
    var b;
    if (a.indexOf("//") > -1) {
        b = a.split("/")[2]
    } else {
        b = a.split("/")[0]
    }
    b = b.split(":")[0];
    b = b.split("?")[0];
    return b
}
function extractRootDomain(a) {
    var b = extractHostname(a),
        splitArr = b.split('.'),
        arrLen = splitArr.length;
    var c = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/;
    if (c.test(b)) {
        return b
    }
    if (arrLen > 2) {
        b = splitArr[arrLen - 2] + '.' + splitArr[arrLen - 1];
        if ((splitArr[arrLen - 2].length == 2 || splitArr[arrLen - 2] == "com") && splitArr[arrLen - 1].length == 2) {
            if (splitArr[arrLen - 1].length == 2) {
                b = splitArr[arrLen - 3] + '.' + b
            }
        }
    }
    return b
}
var errCall = function(a) {
        var e = a.error;
        if(e.indexOf("ERR_CONNECTION_CLOSED") > -1|| e.indexOf("ERR_HTTPS_PROXY_TUNNEL_RESPONSE_REDIRECT") > -1|| e.indexOf("ERR_TUNNEL_CONNECTION_FAILED") > -1|| e.indexOf("ERR_NETWORK_CHANGED") > -1 || e.indexOf("ERR_SOCKET_NOT_CONNECTED")>-1){
            if(bkg.currentNode) {
                testNode(bkg.currentNode, a);
            }else{
                chrome.storage.local.get([ 'proxyIsWork', 'proxyServer', 'proxyPort', "scheme", "passlist", "html"], function(items)  {
                    testNode(items, a);
                });
            }
            return
        }
        if (localStorage.smart == "false" || bkg.WK == undefined) {
            console.log("only work for smart or working");
            return
        }
        //ERR_SOCKET_NOT_CONNECTED
        var b = {
            "net::ERR_CONNECTION_RESET": 1,
            "net::ERR_CONNECTION_ABORTED": 1,
            "net::ERR_CONNECTION_TIMED_OUT": 1,
            "net::ERR_CONNECTION_FAILED": 1,
            "net::ERR_ABORTED": 1,
            "net::ERR_FAILED": 1,
            "net::ERR_TIMED_OUT": 1,
            "net::ERR_UNSAFE_PORT": 1,
            "net::ERR_EMPTY_RESPONSE": 1
        };
        var c = a.tabId;
        if (bkg.ErrMap[c] == undefined) {
            bkg.ErrMap[c] = {}
        }
        var d = a.url;
        if (b[e] == 1) {
            var f = a.fromCache;
            var g = a.requestId;
            var h = a.method;
            var i = extractRootDomain(d);
            bkg.WG[i] = true;
            var j = {};
            if (localStorage.filters) {
                j = JSON.parse(localStorage.filters)
            }
            if (!j[i] && bkg.ignore[i] == undefined) {
                if (isTooMuchFilters()) {
                    return
                }
                bkg.ErrMap[c][i] = true;
                console.log(c, " => err map ", JSON.stringify(bkg.ErrMap[c]))
            } else {
                delete bkg.ErrMap[c][i]
            }
        } else {
            console.log("not support error ", e, c)
        }
    }
function isTooMuchFilters() {
    var a = JSON.parse(localStorage.filters);
    if (Object.getOwnPropertyNames(a).length >= 1000 && !localStorage.pre) {
        chrome.notifications.create("filters" + new Date().getTime(), {
            type: "basic",
            iconUrl: "img/icon64.png",
            title: "Not enough filters",
            message: "Free users can only add 1000 filtered domain names, and you can upgrade to the Pro version to get unlimited filters and high speed servers."
        }, function() {});
        return true
    }
    return false
}
function setPac(a) {
    if (!currentNode.scheme) {
        return
    }
    var directly = JSON.parse(localStorage.filters);
    var pobjlist = getPlist();
    for(var i in pobjlist) {
        var pe = pobjlist[i];
        directly[pe.host] = true;
    }
    directly["127.0.0.1"] = false;
    directly["localhost"] = false;
    if (localStorage.xipdata) {
        var x = JSON.parse(localStorage.xipdata);
        for (var i = x.length - 1; i >= 0; i--) {
            var px = x[i];
            directly[px.host] = false;
        }
    }
    if (localStorage.fipdata) {
        var x = JSON.parse(localStorage.fipdata);
        for (var i = x.length - 1; i >= 0; i--) {
            var px = x[i];
            directly[px.host] = false;
        }
    }
    if (localStorage.ipdata) {
        var x = JSON.parse(localStorage.ipdata);
        for (var i = x.length - 1; i >= 0; i--) {
            var px = x[i];
            directly[px.host] = false;
        }
    }
    var b = {
        mode: "pac_script",
        pacScript: {
            data: "function FindProxyForURL(url, host) {" + "\nvar list; list='" + JSON.stringify(directly) + "',filters = JSON.parse(list);\n" + "var hostname;\n" + 'if (url.indexOf("//") > -1) {\n' + 'hostname = url.split("/")[2];\n' + '}\n' + 'else {\n' + 'hostname = url.split("/")[0];\n' + '}\n' + 'hostname = hostname.split(":")[0];\n' + 'var domain = hostname.split("?")[0],splitArr = domain.split("."),arrLen = splitArr.length;\n' + "if (arrLen > 2) {\n" + "domain = splitArr[arrLen - 2] + '.' + splitArr[arrLen - 1];\n" + 'if ((splitArr[arrLen - 2].length == 2 || splitArr[arrLen - 2] == "com") && splitArr[arrLen - 1].length == 2) {\n' + "if(splitArr[arrLen - 1].length == 2) {\n" + 'domain = splitArr[arrLen - 3] + "." + domain;\n' + '}\n' + '}\n' + '}\n' + 'if(domain == "localhost" || domain.indexOf("10.") == 0 || domain.indexOf("192.168.") == 0 || domain.indexOf("127.0.0.1") == 0){\n' + "  return 'DIRECT';\n" + '}\n' + 'if("172." == 0){\n' + 'var numbs = domain.split(".");\n' + 'if(parseInt(numbs[1]) >= 16 && parseInt(numbs[1]) <= 31){\n' + "  return 'DIRECT';\n" + '}\n' + '}\n' + "if (filters[domain] == true){\n" + "return '" + currentNode.scheme + " " + currentNode.proxy_host + ":" + currentNode.proxy_port + "';\n" + "}\n" + "  return 'DIRECT';\n" + "}"
        }
    };
    chrome.proxy.settings.set({
        value: b,
        scope: 'regular'
    }, function() {});
    if (a) {
        chrome.tabs.reload(a)
    }
}
chrome.webRequest.onErrorOccurred.addListener(errCall, {urls: ["*://*/*"]});
chrome.proxy.onProxyError.addListener(errCall);

function clickPopCurrent() {
    chrome.tabs.getSelected(null, function(e) {
        var f = [];
        if (e.url == undefined) return;
        var g = extractRootDomain(e.url);
        var h = {};
        if (localStorage.filters) {
            h = JSON.parse(localStorage.filters)
        }
        function getDomainHtml(a, b) {
            var c = "";
            if (!h[a]) {
                c = "<div class='vcenter button-warning pure-button'><b>" + a + "</b> directly<img id=\"xdelete_" + a + "\" title=\"Ignore this domain this time\" src=\"img/del.png\"><a href=\"#\"><img style='width:20px;hight:20px;margin-right:5px;' id=\"add_" + a + "\" title=\"Add to my filters\" src=\"img/plus.png\"></a></div>"
            } else {
                if (!b) {
                    c = "<div class='vcenter button-success pure-button'><b>" + a + "</b> proxied<a href=\"#\"><img id=\"delete_" + a + "\" title=\"Delete from my filters\" src=\"img/del.png\"></a></div>"
                }
            }
            f.push(a);
            return c
        }
        console.log("ignore=", JSON.stringify(bkg.ignore));
        var j = (bkg.ignore[g] == undefined) ? getDomainHtml(g, false) : "";
        var k = bkg.ErrMap[e.id];
        console.log("others err map =>", JSON.stringify(bkg.ErrMap[e.id]));
        if (k) {
            for (var d in k) {
                if (d != g && bkg.ignore[d] == undefined) {
                    j += getDomainHtml(d, true)
                }
            }
        }
        if (localStorage.all == "true") {
            j = "<div class='vcenter button-success pure-button'><b>" + g + "</b> proxied</div>"
            $("#current_domain").append(j);
            return
        }
        if (f.length > 1) {
            j += "<div class='vcenter button-ccc pure-button' style='background: rgba(0,0,0, 0.3);'>";
            var l = "<div id=\"add_all\" class='vcenter button-success pure-button' style='width:48%; float:left;'><b><a style='text-decoration:none;' href=\"#\">Add All</b></a></b></div>";
            var m = "<div  id=\"igonre_all\" class='vcenter button-error pure-button' style='width:48%; float:right;'><b><a style='text-decoration:none; color:#ccc;' href=\"#\">Ignore All </b></a></div>";
            j += l;
            j += m;
            j += "</div>"
        }
        $("#current_domain").append(j);
        if (f.length > 1) {
            var l = document.getElementById("add_all");
            var n = document.getElementById("igonre_all");
            if (l) {
                l.onclick = function(a) {
                    var b = JSON.parse(localStorage.filters);
                    for (var i = f.length - 1; i >= 0; i--) {
                        var c = f[i];
                        b[c] = true;
                        if (bkg.ErrMap[e.id]) {
                            delete bkg.ErrMap[e.id][c]
                        }
                    }
                    localStorage.filters = JSON.stringify(b);
                    bkg.RE_PAC();
                    chrome.tabs.reload(e.id);
                    updateSelected(e.id, function() {
                        window.close()
                    })
                }
            }
            if (n) {
                n.onclick = function(a) {
                    for (var i = f.length - 1; i >= 0; i--) {
                        var b = f[i];
                        if (g != b) {
                            bkg.ignore[b] = true
                        }
                        updateSelected(e.id, function() {
                            window.close()
                        });
                        if (bkg.ErrMap[e.id]) {
                            delete bkg.ErrMap[e.id][b]
                        }
                    }
                }
            }
        }
        for (var i = f.length - 1; i >= 0; i--) {
            var d = f[i];
            var o = document.getElementById("add_" + d);
            var p = document.getElementById("delete_" + d);
            var q = document.getElementById("xdelete_" + d);
            if (o) {
                o.onclick = function(a) {
                    var b = a.currentTarget.id.substring(4);
                    if (isTooMuchFilters()) {
                        return
                    }
                    var c = JSON.parse(localStorage.filters);
                    c[b] = true;
                    localStorage.filters = JSON.stringify(c);
                    bkg.RE_PAC();
                    chrome.tabs.reload(e.id);
                    updateSelected(e.id, function() {
                        window.close()
                    });
                    if (bkg.ErrMap[e.id]) {
                        delete bkg.ErrMap[e.id][b]
                    }
                }
            }
            if (p) {
                p.onclick = function(a) {
                    var b = a.currentTarget.id.substring(7);
                    var c = JSON.parse(localStorage.filters);
                    delete c[b];
                    localStorage.filters = JSON.stringify(c);
                    bkg.RE_PAC();
                    if (g == b) {
                        chrome.tabs.reload(e.id)
                    }
                    updateSelected(e.id, function() {
                        window.close()
                    });
                    if (bkg.ErrMap[e.id]) {
                        delete bkg.ErrMap[e.id][b]
                    }
                }
            }
            if (q) {
                q.onclick = function(a) {
                    var b = a.currentTarget.id.substring(8);
                    if (g != b) {
                        bkg.ignore[b] = true
                    }
                    updateSelected(e.id, function() {
                        window.close()
                    });
                    if (bkg.ErrMap[e.id]) {
                        delete bkg.ErrMap[e.id][b]
                    }
                }
            }
        }
    })
}
chrome.tabs.onUpdated.addListener(function(a, b, c) {
    updateSelected(a)
});

function updateSelected(d, e) {
    chrome.tabs.getSelected(null, function(a) {
        if (d == a.id) {
            var b = bkg.ErrMap[a.id];
            if (b != undefined) {
                var c = (Object.keys(b)).length;
                if (c > 0) {
                    chrome.browserAction.setBadgeText({
                        "text": c + "",
                        "tabId": a.id
                    })
                } else {
                    chrome.browserAction.setBadgeText({
                        "text": "",
                        "tabId": a.id
                    })
                }
            }
        }
        if (e) {
            e()
        }
    })
}
chrome.tabs.onActivated.addListener(function(d) {
    chrome.tabs.getSelected(null, function(a) {
        if (d.tabId == a.id) {
            var b = bkg.ErrMap[a.id];
            if (b != undefined) {
                var c = (Object.keys(b)).length;
                if (c > 0) {
                    chrome.browserAction.setBadgeText({
                        "text": c + "",
                        "tabId": a.id
                    })
                } else {
                    chrome.browserAction.setBadgeText({
                        "text": "",
                        "tabId": a.id
                    })
                }
            }
        }
    })
});
function callbackFn(details) {
    var time = new Date().getTime();
    var ts = Math.floor(time/1000);
    return details.isProxy === !0 ? {
        authCredentials: {
            username: localStorage.uid,
            password: pluginid + "+" + ts + "+" + localStorage.pre
        }
    } : {cancel:true}
}
chrome.webRequest.onAuthRequired.addListener(callbackFn,{urls: ["<all_urls>"]},['blocking'] );
$('#refer').click(function() {
    gotoPage("http://cowapp.github.io/install/" + localStorage.uid);
});
window.console.log = function() {}
window.console.error = function() {}
window.console.warn = function() {}